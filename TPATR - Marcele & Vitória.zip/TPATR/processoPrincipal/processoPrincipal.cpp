#define WIN32_LEAN_AND_MEAN
#include <windows.h>    // MAX_PATH, CreateProcess, GetModuleFileName
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <filesystem>
#include <conio.h>		// _getch

// Variáveis globais
typedef unsigned *CAST_LPDWORD;
const DWORD processesNumber = 3;

#define teclaS 0x73
#define teclaM 0x6D
#define teclaR 0x72
#define teclaP 0x70
#define teclaG 0x67
#define tecla1 0x31
#define tecla2 0x32
#define ESC 0x1B

int tecla = 0;

//--------------------------------------------------
//     INICIALIZAÇÃO DA ESTRUTURA DE CONTROLE
//--------------------------------------------------

struct processo {
	bool processStatus = false;
	//STARTUPINFO si{};
	STARTUPINFOW si{};
	PROCESS_INFORMATION newProcessInfo{};
	DWORD creationFlag = 0;
	std::string processName = "";
	std::wstring processPath = L"";
};

processo Produtor;
processo Exibicao;
processo GestaoDeProducao;

// Estrutura de dados que reúne os processos-filhos e seus respectivos nomes
std::vector<std::pair<processo*, std::string>> processos = {
	{&GestaoDeProducao, "Processo de Gestão de Produção"},
	{&Produtor, "Processo Produtor"},
	{&Exibicao, "Processo de Exibição"}
};

// Estrutura de dados que reúne os handles dos processos-filhos
std::vector<HANDLE> handlesDosProcessos;

struct evento { // não gostei muito disso daqui não
	HANDLE eventoDeEncerramentoPrematuroDeUmProcessoFilho;
	HANDLE eventoDeEncerramentoDosProcessosFilhos;
	HANDLE eventoDeAlternarEstadoDaLeituraDoSupervisorio;
	HANDLE eventoDeAlternarEstadoDaLeituraDoPCP;
	HANDLE eventoDeAlternarEstadoDaRetiradaDeMensagens;
	HANDLE eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso;
	HANDLE eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao;
};

evento eventos;

// Estrutura de dados que reúne os handles dos eventos de sincronização
std::vector<HANDLE> handlesDosEventos;

bool inicializarProcesso(processo &processo) {

	// Inicialização dos atributos dos processos-filhos
	processo.processStatus = FALSE;
	ZeroMemory(&processo.si, sizeof(processo.si));
	ZeroMemory(&processo.newProcessInfo, sizeof(processo.newProcessInfo));
	processo.si.cb = sizeof(processo.si);

	// Criação dos processos-filhos
	//Ficou incompativel com o meu
	//processo.processStatus = CreateProcess(
	processo.processStatus = CreateProcessW(
		processo.processPath.c_str(), // Caminho do executável, criado durante a compilação
		NULL,                         // Argumentos da linha de comando
		NULL,                         // Atributos de segurança do processo
		NULL,                         // Atributos de segurança da thread
		FALSE,                        // Herança de identificadores
		processo.creationFlag,        // Flags de criação
		NULL,                         // Ambiente do novo processo
		NULL,                         // Diretório de trabalho do novo processo
		&processo.si,                 // Informações de inicialização
		&processo.newProcessInfo);    // Informações do processo criado

	if (!processo.processStatus) {
		std::cout << "Erro na criação do processo " << processo.processName << "! Codigo: " << GetLastError() << std::endl;
		return false;
	}
	else {
		std::cout << "Processo " << processo.processName << " criado com sucesso! PID: " << processo.newProcessInfo.dwProcessId << std::endl;
	}

	return true;
}

void encerrarProcessosFilhos(std::vector<std::pair<processo*, std::string>> &processos) {

	if (eventos.eventoDeEncerramentoDosProcessosFilhos != nullptr) {

		if (!SetEvent(eventos.eventoDeEncerramentoDosProcessosFilhos)) {
			std::cout << "Erro ao sinalizar o evento de encerramento dos processos-filhos. Código de saída: " << GetLastError() << std::endl;
		};

		for (auto& [processo, nomeDoProcesso] : processos) {

			if ((*processo).newProcessInfo.hProcess != nullptr) {

				DWORD waitResult = WaitForSingleObject((*processo).newProcessInfo.hProcess, INFINITE); // Espera o encerramento de um processo-filho de cada vez
			
				if (waitResult == WAIT_OBJECT_0) {

					if ((*processo).newProcessInfo.hThread != nullptr) { // Verifica se o handle da thread do processo-filho está preenchido
						// Se sim, fecha-se o handle
						CloseHandle((*processo).newProcessInfo.hThread);
						(*processo).newProcessInfo.hThread = nullptr;
					}

					if ((*processo).newProcessInfo.hProcess != nullptr) { // Verifica se o handle do processo-filho está preenchido
						// Se sim, fecha-se o handle
						CloseHandle((*processo).newProcessInfo.hProcess);
						(*processo).newProcessInfo.hProcess = nullptr;
					}

					std::cout << "Processo " << nomeDoProcesso << " finalizado com sucesso." << std::endl;

				} else if (waitResult == WAIT_FAILED) {
					std::cout << "Erro ao aguardar o encerramento do processo " << nomeDoProcesso << ". Código de saída: " << GetLastError() << std::endl;

				} else {
					std::cout << "Resultado inesperadoao aguardar processo " << nomeDoProcesso << " encerrar." << std::endl;
				}
			}
			
		}

	} else {
		std::cout << "Handle do evento de encerramento inválido." << std::endl;
		return;
	}
}

//--------------------------------------------------
//   FUNÇÃO DE MONITORAMENTO DOS PROCESSOS-FILHOS
//--------------------------------------------------

unsigned __stdcall monitorarProcessosFilhos(void* param) {

	std::cout << "Thread secundária iniciou o monitoramento dos processos-filhos." << std::endl;

	auto* handles = static_cast<std::vector<HANDLE>*>(param);

	DWORD waitResult = WaitForMultipleObjects(processesNumber, 
											  (*handles).data(),
											  FALSE,
											  INFINITE);

	if (waitResult >= WAIT_OBJECT_0 && waitResult < WAIT_OBJECT_0 + processesNumber) {
		int index = waitResult - WAIT_OBJECT_0;

		DWORD threadSecundariaExitCode;

		if (GetExitCodeProcess((*handles)[index], &threadSecundariaExitCode)) { // Se GetExitCodeProcess() retornar true, significa apenas que a consulta foi bem-sucedida

			if (WaitForSingleObject(eventos.eventoDeEncerramentoDosProcessosFilhos, 0) == WAIT_TIMEOUT) {

				std::cout << "O processo-filho " << index + 1 << " finalizou prematuramente. Código de saída: " << threadSecundariaExitCode << std::endl;
				SetEvent(eventos.eventoDeEncerramentoPrematuroDeUmProcessoFilho);


			}
			// Se o programa não cai no if acima, é porque o procedimento padrão de encerramento dos processos-filhos foi iniciado

		} else {
			std::cout << "Erro ao obter o código de saída do processo-filho " << index + 1 << ". Código: " << GetLastError() << std::endl;
		}

		return 1;

	} else {
		std::cout << "Erro no monitoramento dos processos-filhos. Código: " << GetLastError() << std::endl;
	}

	return 0;
}
bool enviarComandoLimpeza(const wchar_t* nomeMailslot) {

    HANDLE mailslot = CreateFileW(nomeMailslot, GENERIC_WRITE, FILE_SHARE_READ, nullptr, OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL, nullptr );

    if (mailslot == INVALID_HANDLE_VALUE) {
        std::cout << "[Processo Principal] Erro ao abrir mailslot: " << GetLastError() << std::endl;
        return false;
    }

    const char comando[] = "LIMPAR";
    DWORD bytesEscritos = 0;

    BOOL envio = WriteFile( mailslot, comando, sizeof(comando) - 1, &bytesEscritos, nullptr );

    DWORD erro = envio ? ERROR_SUCCESS : GetLastError();

    CloseHandle(mailslot);

    if (!envio || bytesEscritos != sizeof(comando) - 1) {
        std::cout << "[Processo Principal] Falha ao enviar comando de limpeza: " << erro << std::endl;
        return false;
    }

    return true;
}
//--------------------------------------------------
//  FUNÇÃO DE EXIBIÇÃO DO MENU DE OPÇÕES DO SISTEMA
//--------------------------------------------------

//void menu(evento& eventos, std::vector<std::pair<processo*, std::string>>& processos) {
void menu(evento& eventos) {
	do {
		std::cout << "----------------------------------------" << std::endl;
		std::cout << "         MENU DE OPÇÕES DO SISTEMA      " << std::endl;
		std::cout << "----------------------------------------" << std::endl;
		std::cout << "Digite 's' para bloquear/desbloquear a leitura do Supervisório." << std::endl;
		std::cout << "Digite 'm' para bloquear/desbloquear a leitura do sistema PCP." << std::endl;
		std::cout << "Digite 'r' para bloquear/desbloquear a retirada de mensagens." << std::endl;
		std::cout << "Digite 'p' para bloquear/desbloquear a exibição dos dados de processo." << std::endl;
		std::cout << "Digite 'g' para bloquear/desbloquear a exibição da gestão de produção." << std::endl;
		std::cout << "Digite '1' para solicitar a limpeza da janela da tarefa de exibição dos dados de processo." << std::endl;
		std::cout << "Digite '2' para solicitar a limpeza da janela da tarefa de gestão da produção." << std::endl;
		std::cout << "Digite 'ESC' para sair." << std::endl;
		std::cout << "----------------------------------------" << std::endl;

		while (!_kbhit()) { // Aguarda que o usuário forneça uma entrada. Enquanto isso não acontece, monitora-se o estado dos processos-filhos

			DWORD falhaPrematuraDeUmProcessoFilho = WaitForSingleObject(eventos.eventoDeEncerramentoPrematuroDeUmProcessoFilho,
																		0); // Retorna imediatamente

			if (falhaPrematuraDeUmProcessoFilho == WAIT_OBJECT_0) {

				std::cout << "Um dos processos-filhos falhou prematuramente. O sistema será encerrado." << std::endl;
				SetEvent(eventos.eventoDeEncerramentoDosProcessosFilhos);
				return;

			} else if (falhaPrematuraDeUmProcessoFilho == WAIT_FAILED) {

				std::cout << "Erro ao aguardar o evento de falha prematura de um processo-filho. Código de saída: " << GetLastError() << std::endl;
			}

			
			WaitForSingleObject(
				eventos.eventoDeEncerramentoPrematuroDeUmProcessoFilho,
				100
			);
      
		}

		tecla = _getch(); // Captura a entrada fornecida pelo usuário

		if (tecla == ESC) {
			std::cout << "O sistema está sendo encerrado." << std::endl;
			SetEvent(eventos.eventoDeEncerramentoDosProcessosFilhos);
		}
		else if (tecla == 's') {
			SetEvent(eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio);
		}
		else if (tecla == 'm') {
			SetEvent(eventos.eventoDeAlternarEstadoDaLeituraDoPCP);
		}
		else if (tecla == 'r') {
			SetEvent(eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens);
		}
		else if (tecla == 'p') {
			SetEvent(eventos.eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso);
		}
		else if (tecla == 'g') {
			SetEvent(eventos.eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao);
		}
		else if (tecla == '1') {
			if (enviarComandoLimpeza( L"\\\\.\\mailslot\\comunicacaoSupervisorio" )) std::cout << "[Processo Principal] Comando de limpeza da Exibicao enviado." << std::endl;
		}
		else if (tecla == '2') {
			 if (enviarComandoLimpeza( L"\\\\.\\mailslot\\controleGestao")) std::cout << "[Processo Principal] Comando de limpeza da Gestao enviado." << std::endl;
		}
		else {
			std::cout << "Opção de entrada inválida. Por favor, forneça uma entrada válida." << std::endl;
		}

	} while (tecla != ESC);

}

//--------------------------------------------------
//	     MECANISMOS PARA ESTABELECIMENTO DE 
//		     COMUNICAÇÃO ENTRE PROCESSOS
//--------------------------------------------------

// ...

namespace fs = std::filesystem;

int main() {

	SetConsoleOutputCP(CP_UTF8); // Configura a saída do console para UTF-8

	//--------------------------------------------------
	//				DECLARAÇÃO DOS EVENTOS
	//--------------------------------------------------

	eventos.eventoDeEncerramentoPrematuroDeUmProcessoFilho = CreateEventW(nullptr, true, false,  L"eventoDeEncerramentoPrematuroDeUmProcessoFilho");

	handlesDosEventos.push_back(eventos.eventoDeEncerramentoPrematuroDeUmProcessoFilho);

	eventos.eventoDeEncerramentoDosProcessosFilhos = CreateEventW(nullptr, true, false, L"eventoDeEncerramentoDosProcessosFilhos");

	handlesDosEventos.push_back(eventos.eventoDeEncerramentoDosProcessosFilhos);

	// Evento de controle da tecla 'r'
	eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens = CreateEventW(nullptr,FALSE,	FALSE,L"eventoDeAlternarEstadoDaRetiradaDeMensagens");

	if (eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens == nullptr) {
		std::cout<< "[Processo Principal] Erro ao criar evento da tecla r. Codigo: "<< GetLastError()<< std::endl;
		return 1;
	}
	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens);


	// Evento de controle da tecla 's'
	eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio =	CreateEventW(nullptr, FALSE, FALSE, L"eventoDeAlternarEstadoDaLeituraDoSupervisorio");

	if (eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio == nullptr) {
		std::cout << "[Processo Principal] Erro ao criar evento da tecla s: "<< GetLastError() << std::endl;
		return 1;
	}

	handlesDosEventos.push_back(eventos.eventoDeEncerramentoDosProcessosFilhos);

	// Evento de controle da tecla 'r'
	eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens = CreateEventW(nullptr,FALSE,	FALSE,L"eventoDeAlternarEstadoDaRetiradaDeMensagens");

	if (eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens == nullptr) {
		std::cout<< "[Processo Principal] Erro ao criar evento da tecla r. Codigo: "<< GetLastError()<< std::endl;
		return 1;
	}
	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaRetiradaDeMensagens);


	// Evento de controle da tecla 's'
	eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio =	CreateEventW(nullptr, FALSE, FALSE, L"eventoDeAlternarEstadoDaLeituraDoSupervisorio");

	if (eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio == nullptr) {
		std::cout << "[Processo Principal] Erro ao criar evento da tecla s: "<< GetLastError() << std::endl;
		return 1;
	}

	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaLeituraDoSupervisorio);

	// Evento de controle da tecla 'm'
	eventos.eventoDeAlternarEstadoDaLeituraDoPCP =	CreateEventW(nullptr,FALSE,	FALSE,	L"eventoDeAlternarEstadoDaLeituraDoPCP");

	if (eventos.eventoDeAlternarEstadoDaLeituraDoPCP == nullptr) {
		std::cout<< "[Processo Principal] Erro ao criar evento da tecla m: "<< GetLastError() << std::endl;
		return 1;
	}
	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaLeituraDoPCP);

	// Evento de bloqueio/desbloqueio da exibição
	eventos.eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso =CreateEventW(nullptr,FALSE,	FALSE,	L"eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso");

	if (eventos.eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso == nullptr) {
		std::cout << "[Processo Principal] Erro ao criar evento da tecla p: "<< GetLastError() << std::endl;
		return 1;
	}
	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaExibicaoDosDadosDeProcesso);

	// Evento de bloqueio/desbloqueio da Gestão de Produção
	eventos.eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao = CreateEventW(nullptr,FALSE,FALSE,L"eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao");

	if (eventos.eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao == nullptr) {
		std::cout << "[Processo Principal] Erro ao criar evento da tecla g: "<< GetLastError() << std::endl;
		return 1;
	}
	handlesDosEventos.push_back(eventos.eventoDeAlternarEstadoDaExibicaoDaGestaoDeProducao);





	//--------------------------------------------------
	//	  OBTENÇÃO DO DIRETÓRIO DOS EXECUTÁVEIS
	//--------------------------------------------------

	wchar_t currentPath[MAX_PATH];

	//DWORD dwResult = GetModuleFileName(NULL, currentPath, MAX_PATH);
	DWORD dwResult = GetModuleFileNameW(NULL, currentPath, MAX_PATH);

	if (dwResult == 0) {
		std::cout << "[Proceso Principal] Erro ao obter o caminho do executável atual. Código de saída: " << GetLastError() << std::endl;
		return 1;
	}
	else if (dwResult > MAX_PATH) {
		std::cout << "[Proceso Principal] O caminho do executável atual pode ter sido truncado." << std::endl;
		return 1;
	}

	fs::path directory = fs::path(currentPath).parent_path(); // Obtém o diretório do executável atual

	// Bloco de montagem dos caminhos dos executáveis dos processos filhos
	GestaoDeProducao.processPath = directory / L"processoGestaoDeProducao.exe";
	Produtor.processPath = directory / L"processoProdutor.exe";
	Exibicao.processPath = directory / L"processoExibicao.exe";

	//--------------------------------------------------
	//		    INICIALIZAÇÃO DOS EXECUTÁVEIS 
	//			    DOS PROCESSOS FILHOS
	//--------------------------------------------------

	GestaoDeProducao.creationFlag = CREATE_NEW_CONSOLE;
	Produtor.creationFlag = 0;
	Exibicao.creationFlag = CREATE_NEW_CONSOLE;

	bool inicializacaoBemSucedida = true;

	for (auto& [processo, nomeDoProcesso] : processos) {

		if (inicializarProcesso(*processo)) {
			// Se a inicialização for bem-sucedida, adiciona o handle do processo à estrutura 
			handlesDosProcessos.push_back((*processo).newProcessInfo.hProcess);
		} else {
			inicializacaoBemSucedida = false;
			break; // Impedir que os demais processos sejam inicializados
		}
	}

	// Rotina de limpeza como tratamento para inicialização mal-sucedida
	if (!inicializacaoBemSucedida) {
		encerrarProcessosFilhos(processos);
		return 1;
	}

	//--------------------------------------------------
	//	MONITORAMENTO DOS ESTADOS DOS PROCESSOS FILHOS
	//--------------------------------------------------

	// Criação de uma thread dedicada ao monitoramento dos estados dos demais executáveis

	HANDLE threadSecundaria;
	DWORD threadSecundariaId;

	threadSecundaria = (HANDLE)_beginthreadex(NULL,
											  0,
											  monitorarProcessosFilhos,
											  &handlesDosProcessos,
											  0,
											  (CAST_LPDWORD) &threadSecundariaId
	);

	if (threadSecundaria) {
		std::cout << "[Proceso Principal] Thread de monitoramento criada com sucesso. ID da thread: " << threadSecundariaId << std::endl;
	}
	else {
		std::cout << "[Proceso Principal] Erro na criação da thread de monitoramento. Código: " << GetLastError() << std::endl;
		encerrarProcessosFilhos(processos);
		return 1;
	}

	//--------------------------------------------------
	//		INTERAÇÃO DO USUÁRIO COM O SISTEMA
	//--------------------------------------------------

	//menu(eventos, processos); // Exibe o menu de opções do sistema e aguarda a entrada do usuário
	menu(eventos);
	//--------------------------------------------------
	//	 AGUARDA O TÉRMINO DA THREAD DE MONITORAMENTO
	//               E FECHA SEU HANDLE
	//--------------------------------------------------

	DWORD waitThreadSecundaria = WaitForSingleObject(threadSecundaria, INFINITE);

	if (waitThreadSecundaria == WAIT_OBJECT_0) {

		std::cout << "[Proceso Principal] Thread secundária devidamente encerrada. Fechando seu handle." << std::endl;
		CloseHandle(threadSecundaria);

	} else if (waitThreadSecundaria == WAIT_FAILED){
		std::cout << "[Proceso Principal] Erro ao aguardar a sinalização da thread secundária. Código de saída: " << GetLastError() << std::endl;

	} else {
		std::cout << "[Proceso Principal] Resultado inesperado ao aguardar o término da thread secundária." << std::endl;
	}

	encerrarProcessosFilhos(processos);

	for (HANDLE handle : handlesDosEventos) {
		if (handle != nullptr) 	CloseHandle(handle);		
	}
	handlesDosEventos.clear();

	return 0;
}